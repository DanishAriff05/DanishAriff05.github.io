<?php
include "function.php";

$nama = $_POST['nama'];
$nric = $_POST['nric'];

echo $nama."<br>";
checkNRIC($nric);

echo"<pre>";
var_dump($_POST);
echo"</pre>";

?>

