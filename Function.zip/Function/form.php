<?php
include "function.php";

?>

<form action="process.php" method="POST">
<p>
    Nama : <input type="text" name="nama"> <br>
    NRIC : <input type="text" name="nric"><br>

    <button type="submit">Submit</button>
</p>








</form>